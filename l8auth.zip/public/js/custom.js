 $(function(){
    if((screen.width<=360) || (screen.width<375) || (screen.width<414) ){
      $('.acoount_icon').show();
    }else{
      $('.acoount_icon').hide();

    }
  });



 



