<div id="banner">
    <div class="col-12 col-sm-12 col-md-11 col-lg-11 col-xl-11 m-auto text-center p-0">
        <a href="#">
            <img class="bannerImage img-fluid" src="<?php echo e(asset('images')); ?>/banner/banner.png" alt="Baner">
        </a>
    </div>
</div>
<?php /**PATH E:\laravel-project\l8auth\resources\views/homePage/banner.blade.php ENDPATH**/ ?>