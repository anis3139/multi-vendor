
    <div id="allproductBanner">
        <a href="#" class="mx-auto">
            <img class="m-auto img-fluid" src="{{asset('images')}}/banner/allProductBanner.jpg" alt="">
        </a>
    </div>



    <div id="allproductBrandslider" class="text-center">
        <div class="row">
            <h5 class="text-right text-danger"><a class="text-decoration-none text-danger" href="#">Top Brand</a></h5>
            <div class="m-auto"></div>
            <h5 class="text-right text-danger"><a class="text-decoration-none text-danger" href="#">See More</a></h5>
        </div>


        <div id="brandSlider">
            <section class="customer-logos slider">
                <div class="slide">
                    <a class="slide" href="#"><img src="{{ asset('images/logo/watchbrand') }}/(0).jpg"></a>
                    <a class="slide" href="#"><img src="{{ asset('images/logo/watchbrand') }}/(1).png"></a>
                </div>
                <div class="slide">
                    <a class="slide" href="#"><img  src="{{ asset('images/logo/watchbrand') }}/(2).jpg"></a>
                    <a class="slide" href="#"><img  src="{{ asset('images/logo/watchbrand') }}/(2).png"></a>
                </div>
                <div class="slide">
                    <a class="slide" href="#"><img src="{{ asset('images/logo/watchbrand') }}/(3).jpg"></a>
                    <a class="slide" href="#"><img src="{{ asset('images/logo/watchbrand') }}/(4).jpg"></a>
                </div>
                <div class="slide">
                    <a class="slide" href="#"><img src="{{ asset('images/logo/watchbrand') }}/(5).jpg"></a>
                    <a class="slide" href="#"><img src="{{ asset('images/logo/watchbrand') }}/(6).jpg"></a>
                </div>
                <div class="slide">
                    <a class="slide" href="#"><img src="{{ asset('images/logo/watchbrand') }}/(7).jpg"></a>
                    <a class="slide" href="#"><img src="{{ asset('images/logo/watchbrand') }}/(8).jpg"></a>
                </div>
                <div class="slide">
                    <a class="slide" href="#"><img src="{{ asset('images/logo/watchbrand') }}/(9).jpg"></a>
                    <a class="slide" href="#"><img src="{{ asset('images/logo/watchbrand') }}/(10).jpg"></a>
                </div>
                <div class="slide">
                    <a class="slide" href="#"><img src="{{ asset('images/logo/watchbrand') }}/(0).jpg"></a>
                    <a class="slide" href="#"><img src="{{ asset('images/logo/watchbrand') }}/(2).jpg"></a>
                </div>
                <div class="slide">
                    <a class="slide" href="#"><img src="{{ asset('images/logo/watchbrand') }}/(3).jpg"></a>
                    <a class="slide" href="#"><img src="{{ asset('images/logo/watchbrand') }}/(4).jpg"></a>
                </div>
                <div class="slide">
                    <a class="slide" href="#"><img src="{{ asset('images/logo/watchbrand') }}/(5).jpg"></a>
                    <a class="slide" href="#"><img src="{{ asset('images/logo/watchbrand') }}/(6).jpg"></a>
                </div>
             </section>
        </div>
    </div>
